import { NewdirectiveDirective } from './newdirective.directive';

describe('NewdirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new NewdirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
