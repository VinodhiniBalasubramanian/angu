import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewdirectiveDirective } from './newdirective.directive';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [ NewdirectiveDirective],
  exports:[ NewdirectiveDirective]
})
export class MyModuleModule { }
