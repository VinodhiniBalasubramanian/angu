import { Directive, ElementRef,Renderer, HostListener} from '@angular/core';

@Directive({
  selector: '[appNewdirective]'
})
export class NewdirectiveDirective {

  constructor(private x1:ElementRef,private renderer: Renderer) {
    //renderer.setElementStyle(x1.nativeElement, 'backgroundColor', 'red');
  }
  @HostListener('mouseenter') onMouseEnter() {
    this.renderer.setElementStyle(this.x1.nativeElement, 'backgroundColor', 'blue');
}
  @HostListener('mouseleave') onMouseLeave() {
  this.renderer.setElementStyle(this.x1.nativeElement, 'backgroundColor', '');
}
}
