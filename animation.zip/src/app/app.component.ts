import { Component } from '@angular/core';
import {trigger,state,style,animate,transition, keyframes} from '@angular/animations';

@Component({
  selector: 'app-root',
  template :` <ul>
  <li *ngFor="let word of words"
      [@myAnimation]>{{word}}
  </li>
</ul>
`,
  styles:['p{width:200px;background:hotpink;margin:100px auto;text-align:center;}'],
  animations: [
    trigger('myAnimation', [
      state('in', style({transform: 'translateX(0)'})),
      transition('void => *', [
        style({transform: 'translateX(-100%)'}),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({transform: 'translateX(100%)'}))
      ])
    ])
  ]
})
export class AppComponent {
  words=['A','B','C'];
  
  }

