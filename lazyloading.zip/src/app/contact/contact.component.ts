import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  template :`<p>Contact Component</p>`
})
export class ContactComponent {

}
