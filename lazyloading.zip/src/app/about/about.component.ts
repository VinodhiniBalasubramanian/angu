import { Component } from '@angular/core';

@Component({
  selector: 'app-contact',
  template :`<p>About Component</p>`
})
export class AboutComponent  {

}
